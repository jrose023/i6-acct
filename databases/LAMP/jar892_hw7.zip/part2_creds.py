#!/usr/local/bin/python3
# variables for authentication for using python with mysql 
host="warehouse" 
user="jar892" 
passwd="y9t9up8q" 
db="jar892_hw7" 
